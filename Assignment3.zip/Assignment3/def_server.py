
import numpy as np
import socket
from _thread import *
import pickle

import uuid
import time 
import rsa
import sys 

server = "localhost"
port = 5552
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

counter = 0 
rows = 20 

try:
    s.bind((server, port))
except socket.error as e:
    str(e)

s.listen(2)

conn, addr = s.accept()

m1 = "015" + "congratulations"
m2 = "008" + "good job"
conn.send(m1.encode())
conn.send(m2.encode())


# close 
conn.close()
