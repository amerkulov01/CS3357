

import numpy as np

from network import Network
import time
import rsa 
import sys 
import socket 


# self.server = "10.11.250.207"
server = "localhost"
port = 5552
addr = (server, port)
conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

conn.connect(addr)

print("connected to server")

print("Sleeping")

time.sleep(5) 


h1 = conn.recv(3).decode()
m1 = conn.recv(int(h1)).decode() 

h2 = conn.recv(3).decode()
m2 = conn.recv(int(h2)).decode()


print("h1:",h1)
print("m1:",m1)
print("h2:",h2)
print("m2:",m2)


# close 
conn.close()
